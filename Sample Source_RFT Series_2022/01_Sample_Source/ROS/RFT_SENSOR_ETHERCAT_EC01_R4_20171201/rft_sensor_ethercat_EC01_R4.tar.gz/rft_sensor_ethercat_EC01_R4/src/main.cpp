/*
	RFT Force Torque sensor. - ethercat communication version
	                         - ethercat adaptor board: RFTEC-01<R4>
    
	Simple stand-alone ROS node that takes data from RFT sensor 
	and Publishes it ROS topic	
	
	website: www.robotous.com
	 e-mail: support@robotous.com
	
	Development & Test Evironment
	  - Ubuntu 16.04 LTS
	  - ROS Kinetic
*/

/*
	EtherCAT Lib. 
	Simpe Open EhterCAT Master <https://openethercatsociety.github.io/>
*/

/*
	ver. 0.0.0, 2017.12.01
*/
#define ROS_RFT_EC01_R4_SW_VER	"VER 0.0.0(Read Only)"


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <mutex>
#include <sys/time.h>
#include <unistd.h>
#include <pthread.h>

#include <ros/ros.h>
#include <geometry_msgs/WrenchStamped.h>
#include "rft_sensor_ethercat_EC01_R4/rft_operation.h"	// this file will be automatically generated during build operation.
														// catkin_ws -> devel -> include -> rft_sensor_ethercat_EC01_R4

#include "rft_sensor_defs.h"
			
// for soem
#include "ethercattype.h"
#include "nicdrv.h"
#include "ethercatbase.h"
#include "ethercatmain.h"
#include "ethercatdc.h"
#include "ethercatcoe.h"
#include "ethercatfoe.h"
#include "ethercatconfig.h"
#include "ethercatprint.h"
			
/*
	Definitions
*/
#define RFT_SERVICE_OK  			(0)
#define RFT_SERVICE_RQST_TIMEOUT 	(0xF0)


/*
	Global Variables
*/
std::string g_ethernet_dev  	= "eth0";	// default network interface card.
float		g_force_divider 	= 50.0f;	// for more information to refer the RFT sensor manual
float		g_torque_divider 	= 2000.0f;	// for more information to refer the RFT sensor manual
int			g_slave_id			= 1;		// make sure the id of slave index

// for RFT sensor
unsigned char RFT_DATA_FIELD[17] = { 0 };
unsigned char RFT_OverloadStatus = 0;
unsigned char RFT_ErrorFlag = 0;
short RFT_FT_RAW[6] = { 0 };
float RFT_FT[6] = {0.0f};

// PROCESSING DATA MAPPING FOR RFTEC01 R4
// RFT data field index in RFTEC01 R4 EtherCAT
#define IDX_D1 (4) 
#define IDX_D2 (5)
#define IDX_D3 (6)
#define IDX_D4 (7)
#define IDX_D5 (8)
#define IDX_D6 (9)
#define IDX_D7 (10)
#define IDX_D8 (11)
#define IDX_D9 (16) 
#define IDX_D10 (17)
#define IDX_D11 (18)
#define IDX_D12 (19)
#define IDX_D13 (20)
#define IDX_D14 (21)
#define IDX_D15 (22)
#define IDX_D16 (23)

#define IDX_RAW_FT1 (24) // 2 BYTES
#define IDX_RAW_FT2 (26) // 2 BYTES
#define IDX_RAW_FT3 (28) // 2 BYTES
#define IDX_RAW_FT4 (30) // 2 BYTES
#define IDX_RAW_FT5 (32) // 2 BYTES
#define IDX_RAW_FT6 (34) // 2 BYTES

#define IDX_OVERLOAD 	(36)
#define IDX_ERRLR_FLAG  (37)

// For Output Processing Data... configParam (4Bytes)
unsigned char configCmdType = CMD_NONE;
unsigned char configParam[3] = { 0 };

// for soem
#define EC_TIMEOUTMON (500)
char 				IOmap[4096];
OSAL_THREAD_HANDLE 	thread1;
int 				expectedWKC;
boolean 			needlf;
volatile int 		wkc;
volatile int 		rtcnt;
boolean 			inOP;
uint8 currentgroup = 0;

/*
	Funcitions
*/
void init_param(ros::NodeHandle *n);
bool rft_operation_service(rft_sensor_ethercat_EC01_R4::rft_operation::Request &req, rft_sensor_ethercat_EC01_R4::rft_operation::Response &res);
uint8_t rft_response_wait(uint8_t opType);
uint8_t rft_response_display(uint8_t opType);
uint8_t rft_send_command(rft_sensor_ethercat_EC01_R4::rft_operation::Request &req);

OSAL_THREAD_FUNC ecatcheck(void *lpParam);
bool init_EtherCAT( char *devName );
 
void cvtBufferToInt16( short *value, unsigned char *buff );
void changeRFTEC01_ConfigParam( unsigned char param1, unsigned char param2, unsigned char param3, unsigned char param4 );
void updateRFT_Data( void );
void update_RFTEC01_R4_OutputProcessData(void);

/*
	The main function of RFT EtherCAT Node.....
	- running ROS as root user
	  > sudo -s           <- login as root user
	  > source ~/.bashrc  <- environment setting to use ROS commands as root user.
	- you can send the operation command using 
	  * rqt -> service caller
	- you can see the force/torque data using rqt_plot
	  * rqt_plot /RFT_FORCE/wrench/force
	  * rqt_plot /RFT_FORCE/wrench/torque
*/
int main(int argc, char** argv)
{
	ros::init(argc, argv, "rft_sensor_ethercat_EC01_R4");
	ros::NodeHandle nh;
	
	// initialize parameters
	init_param( &nh );
	
	// initialize EtherCAT port
	if(init_EtherCAT( (char*)g_ethernet_dev.c_str()) == false)
	{
		ROS_ERROR("RFT Force/Torque Sensor - EtherCAT Port Initialization Error");
		return -1;
	}
	
	//service
	ros::ServiceServer op_service = nh.advertiseService("rft_op_service", rft_operation_service);
	//publisher
	geometry_msgs::WrenchStamped ft_data;
	ros::Publisher rft_publisher = nh.advertise<geometry_msgs::WrenchStamped>("RFT_FORCE", 1);
	
	ros::AsyncSpinner spinner(2); // Use 2 threads
    spinner.start();
	
	ROS_INFO("RFT Force/Torque Sensor <EtherCAT> is ready!!!!");
	
	bool isSensorOk = false;
	unsigned long seq = 0;
	ros::Rate rate(1000); // 1KHz
	while(ros::ok())
	{

		update_RFTEC01_R4_OutputProcessData();
		ec_send_processdata();
		wkc = ec_receive_processdata(EC_TIMEOUTRET);
		updateRFT_Data();	

		
		if( (RFT_DATA_FIELD[0] == CMD_FT_CONT) ) // check currnet respons packet type..
		{
			seq++;
			ft_data.header.stamp = ros::Time::now();
			ft_data.header.seq = seq;
			ft_data.wrench.force.x = RFT_FT[0];
			ft_data.wrench.force.y = RFT_FT[1];
			ft_data.wrench.force.z = RFT_FT[2];
			ft_data.wrench.torque.x = RFT_FT[3];
			ft_data.wrench.torque.y = RFT_FT[4];
			ft_data.wrench.torque.z = RFT_FT[5];
			rft_publisher.publish(ft_data);
			
			//ROS_INFO("Published.... %ld", seq);
		}
		
		
		rate.sleep();
	}
	
	return 0;
}

/*
	intialize parameters.
*/
void init_param(ros::NodeHandle *n)
{
	// parameter ethercat network interface card port device
	if(!n->getParam("RFT_NIC_PORT", g_ethernet_dev))
	{
		ROS_WARN("RFT NIC port is not defined, The port is initialized with %s", g_ethernet_dev.c_str());
		n->setParam("RFT_NIC_PORT", g_ethernet_dev.c_str()); // set param
		n->getParam("RFT_NIC_PORT", g_ethernet_dev);   		 // checking 
	}
	ROS_INFO("RFT NIC port: %s", g_ethernet_dev.c_str());
	
	// the slave ID of RFT EtherCAT Sensor/Adaptor
	if(!n->getParam("RFT_SLAVE_ID", g_slave_id))
	{
		ROS_WARN("RFT Slave ID is not defined, the ID is initialized with %d", g_slave_id);
		n->setParam("RFT_SLAVE_ID", g_slave_id); 	// set param
		n->getParam("RFT_SLAVE_ID", g_slave_id);    // checking 
	}
	ROS_INFO("RFT Slave ID: %d", g_slave_id);

	// parameter force/torque divider
	if(!n->getParam("RFT_FORCE_DEVIDER", g_force_divider))
	{
		ROS_WARN("The force divider of RFT sensor is not defined, The force divider is initialized with %f", g_force_divider);
		n->setParam("RFT_FORCE_DEVIDER", g_force_divider); // set param
		n->getParam("RFT_FORCE_DEVIDER", g_force_divider);    // checking 
	}
	ROS_INFO("Force Divider of RFT sensor: %f", g_force_divider);

	if(!n->getParam("RFT_TORQUE_DEVIDER", g_torque_divider))
	{
		ROS_WARN("The torque divider of RFT sensor is not defined, The torque divider is initialized with %f", g_torque_divider);
		n->setParam("RFT_TORQUE_DEVIDER", g_torque_divider); // set param
		n->getParam("RFT_TORQUE_DEVIDER", g_torque_divider);    // checking 
	}
	ROS_INFO("Torque Divider of RFT sensor: %f", g_torque_divider);	
	
	// version setting... only to check the s/w version.
	n->setParam("RFT_EC01_R4_SW_VER", ROS_RFT_EC01_R4_SW_VER);
}

/*
	service operation...
*/
bool rft_operation_service(rft_sensor_ethercat_EC01_R4::rft_operation::Request &req, rft_sensor_ethercat_EC01_R4::rft_operation::Response &res)
{
	//ROS_INFO("RCVD SERVICE REQUEST: %d, %d, %d, %d", req.opType, req.param1, req.param2, req.param3);

	uint8_t commandSend = RFT_SERVICE_OK;
		
	commandSend = rft_send_command( req );
	
	if( commandSend == RFT_SERVICE_OK )
	{
		//ROS_INFO("RESPONSE WAIT");
		// Set bias & Stop command doesn't have response packet.
		if( (req.opType != CMD_SET_BIAS) && (req.opType != CMD_FT_CONT_STOP) ) 
		{
			res.result = rft_response_wait(req.opType);
		}
	}
	else
	{
		res.result = commandSend;
	}
	
	return true;
}

/*
	Send the received operation command
	The detail of the operaion of the RFT Sensor, Please refer to the manual
*/
uint8_t rft_send_command(rft_sensor_ethercat_EC01_R4::rft_operation::Request &req)
{
	uint8_t result = RFT_SERVICE_OK;
	switch( req.opType )
	{
		case CMD_GET_PRODUCT_NAME:
			ROS_INFO("RCVD SERVICE REQUEST: get product name");
			configCmdType = req.opType; 
			configParam[0] = configParam[1] = configParam[2] = 0;
		break;

		case CMD_GET_SERIAL_NUMBER:		
			ROS_INFO("RCVD SERVICE REQUEST: get serial number");
			configCmdType = req.opType; 
			configParam[0] = configParam[1] = configParam[2] = 0;
		break;

		case CMD_GET_FIRMWARE_VER:	
			ROS_INFO("RCVD SERVICE REQUEST: get firmware version");
			configCmdType = req.opType; 
			configParam[0] = configParam[1] = configParam[2] = 0;
		break;

		case CMD_SET_ID:					// Only CAN version
			ROS_INFO("RCVD SERVICE REQUEST: set ID - is not supported");
			result = NOT_SUPPORTED_CMD;
			configCmdType = CMD_NONE; 
			configParam[0] = configParam[1] = configParam[2] = 0;			
		break;

		case CMD_GET_ID:					// Only CAN version
			ROS_INFO("RCVD SERVICE REQUEST: get ID - is not supported");
			result = NOT_SUPPORTED_CMD;
			configCmdType = CMD_NONE; 
			configParam[0] = configParam[1] = configParam[2] = 0;				
		break;

		case CMD_SET_COMM_BAUDRATE:			// Only UART version, CAN : 1Mbps Fixed
			ROS_INFO("RCVD SERVICE REQUEST: set baud-rate - is not supported");
			result = NOT_SUPPORTED_CMD;
			configCmdType = CMD_NONE; 
			configParam[0] = configParam[1] = configParam[2] = 0;		
		break;

		case CMD_GET_COMM_BAUDRATE:	
			ROS_INFO("RCVD SERVICE REQUEST: get baud-rate - is not supported");
			result = NOT_SUPPORTED_CMD;
			configCmdType = CMD_NONE; 
			configParam[0] = configParam[1] = configParam[2] = 0;	
		break;

		case CMD_SET_FT_FILTER:	
			ROS_INFO("RCVD SERVICE REQUEST: set filter type");
			configCmdType = req.opType; 
			configParam[0] = req.param1;
			configParam[1] = req.param2;
			configParam[2] = 0;			
		break;

		case CMD_GET_FT_FILTER:				
			ROS_INFO("RCVD SERVICE REQUEST: get filter type");
			configCmdType = req.opType; 
			configParam[0] = configParam[1] = configParam[2] = 0;	
		break;

		case CMD_FT_ONCE:	
			ROS_INFO("RCVD SERVICE REQUEST: get force/torque once");
			configCmdType = req.opType; 
			configParam[0] = configParam[1] = configParam[2] = 0;			
		break;

		case CMD_FT_CONT:	
			ROS_INFO("RCVD SERVICE REQUEST: get force/torque cont.");
			configCmdType = req.opType; 
			configParam[0] = configParam[1] = configParam[2] = 0;	
		break;

		case CMD_FT_CONT_STOP:			
			ROS_INFO("RCVD SERVICE REQUEST: stop force/torque  - There is no response packet");
			configCmdType = req.opType; 
			configParam[0] = configParam[1] = configParam[2] = 0;	
		break;

		case CMD_RESERVED_1:
			ROS_INFO("RCVD SERVICE REQUEST: is not supprted");
			result = NOT_SUPPORTED_CMD;		
			configCmdType = CMD_NONE; 
			configParam[0] = configParam[1] = configParam[2] = 0;	
		break;

		case CMD_RESERVED_2:		
			ROS_INFO("RCVD SERVICE REQUEST: is not supprted");		
			result = NOT_SUPPORTED_CMD;
			configCmdType = CMD_NONE; 
			configParam[0] = configParam[1] = configParam[2] = 0;	
		break;

		case CMD_SET_CONT_OUT_FRQ: 	
			ROS_INFO("RCVD SERVICE REQUEST: set output frq.");
			configCmdType = req.opType; 
			configParam[0] = req.param1;
			configParam[1] = configParam[2] = 0;			
		break;

		case CMD_GET_CONT_OUT_FRQ: 
			ROS_INFO("RCVD SERVICE REQUEST: get output frq.");
			configCmdType = req.opType; 
			configParam[0] = configParam[1] = configParam[2] = 0;	
		break;

		case CMD_SET_BIAS:		
			ROS_INFO("RCVD SERVICE REQUEST: set bias - There is no response packet....");
			configCmdType = req.opType; 
			configParam[0] = req.param1;
			configParam[1] = configParam[2] = 0;	
		break;

		case CMD_GET_OVERLOAD_COUNT:
			ROS_INFO("RCVD SERVICE REQUEST: get overload count");
			configCmdType = req.opType; 
			configParam[0] = configParam[1] = configParam[2] = 0;	
		break;
	default:
		result = NOT_SUPPORTED_CMD;
		ROS_INFO("RCVD SERVICE REQUEST: is not supprted");	
		configCmdType = CMD_NONE; 
		configParam[0] = configParam[1] = configParam[2] = 0;	
	break;
	}	

	return result;
}

/*
	Display the response packet
	The detail of the response packet of the RFT Sensor, Please refer to the manual
*/
uint8_t rft_response_display(uint8_t opType)
{
	uint8_t result = RFT_SERVICE_OK;
	switch ( opType )
	{
	case CMD_GET_PRODUCT_NAME:
		RFT_DATA_FIELD[16] = 0;
		ROS_INFO("%s", &RFT_DATA_FIELD[1]);
		break;
	case CMD_GET_SERIAL_NUMBER:
		RFT_DATA_FIELD[16] = 0;
		ROS_INFO("%s", &RFT_DATA_FIELD[1]);
		break;
	case CMD_GET_FIRMWARE_VER:
		RFT_DATA_FIELD[16] = 0;
		ROS_INFO("%s", &RFT_DATA_FIELD[1]);
		break;
	case CMD_SET_ID:
		result = NOT_SUPPORTED_CMD;
		break;
	case CMD_GET_ID:
		result = NOT_SUPPORTED_CMD;
		break;
	case CMD_SET_COMM_BAUDRATE:
		ROS_INFO("Cmd Type: %d, Result: %d, Err. Code: %d", RFT_DATA_FIELD[0], RFT_DATA_FIELD[1], RFT_DATA_FIELD[2] );
		result = RFT_DATA_FIELD[2];
		break;
	case CMD_GET_COMM_BAUDRATE:
		ROS_INFO("Baud: %d, new Baud: %d", RFT_DATA_FIELD[1], RFT_DATA_FIELD[2]);
		break;
	case CMD_SET_FT_FILTER:
		ROS_INFO("Cmd Type: %d, Result: %d, Err. Code: %d", RFT_DATA_FIELD[0], RFT_DATA_FIELD[1], RFT_DATA_FIELD[2] );
		result = RFT_DATA_FIELD[2];
		break;
	case CMD_GET_FT_FILTER:
		ROS_INFO("filter type: %d, sub. setting: %d", RFT_DATA_FIELD[1], RFT_DATA_FIELD[2]);
		break;
	case CMD_FT_ONCE:
		ROS_INFO("%0.3f, %.03f, %.03f, %0.3f, %.03f, %.03f",
		RFT_FT[0], RFT_FT[1], RFT_FT[2],
		RFT_FT[3], RFT_FT[4], RFT_FT[5] );	
		break;
	case CMD_FT_CONT:
		// This response packet is published.. see the while() of main() function.
		ROS_INFO("RFT Force Toque topic will be published...");
		break;
	case CMD_FT_CONT_STOP:
		// THERE IS NO - RESPONSE PACKET
		break;
	case CMD_RESERVED_1:
		result = NOT_SUPPORTED_CMD;
		break;
	case CMD_RESERVED_2:
		result = NOT_SUPPORTED_CMD;
		break;
	case CMD_SET_CONT_OUT_FRQ:
		ROS_INFO("Cmd Type: %d, Result: %d, Err. Code: %d", RFT_DATA_FIELD[0], RFT_DATA_FIELD[1], RFT_DATA_FIELD[2] );
		result = RFT_DATA_FIELD[2];
		break;
	case CMD_GET_CONT_OUT_FRQ:
		ROS_INFO("output frq: %d", RFT_DATA_FIELD[1]);
		break;
	case CMD_SET_BIAS:
		// THERE IS NO - RESPONSE PACKET
		break;
	case CMD_GET_OVERLOAD_COUNT:
		ROS_INFO("overload ount: %d, %d, %d, %d, %d, %d", 
		RFT_DATA_FIELD[1], RFT_DATA_FIELD[2], RFT_DATA_FIELD[3],
		RFT_DATA_FIELD[4], RFT_DATA_FIELD[5], RFT_DATA_FIELD[6] );
		break;

	default:
		result = NOT_SUPPORTED_CMD;
		break;
	}	
	
	return result;
}

/*
	Wait the response packet from the RFT sensor
*/
uint8_t rft_response_wait(uint8_t opType)
{
	int result = RFT_SERVICE_OK;
	int waitTimeOut = 0;
	
	bool isRcvd = false;
	do
	{
		if( waitTimeOut >= 50 )
		{
			ROS_WARN("RCVD SERVICE TIMEOUT");
			isRcvd = true;
			result = RFT_SERVICE_RQST_TIMEOUT;
		}
		
		if( opType == RFT_DATA_FIELD[0] ) // check.. response packet type
		{
			isRcvd = true;
			rft_response_display(opType);
		}
		
		waitTimeOut++;
		usleep(10000);
		
	}while( isRcvd == false );
	
	return result;
}

OSAL_THREAD_FUNC ecatcheck(void *lpParam) 
{
    int slave;

    while(1)
    {
        if( inOP && ((wkc < expectedWKC) || ec_group[currentgroup].docheckstate))
        {
            if (needlf)
            {
               needlf = FALSE;
               //ROS_INFO("\n");
            }
            /* one ore more slaves are not responding */
            ec_group[currentgroup].docheckstate = FALSE;
            ec_readstate();
            for (slave = 1; slave <= ec_slavecount; slave++)
            {
               if ((ec_slave[slave].group == currentgroup) && (ec_slave[slave].state != EC_STATE_OPERATIONAL))
               {
                  ec_group[currentgroup].docheckstate = TRUE;
                  if (ec_slave[slave].state == (EC_STATE_SAFE_OP + EC_STATE_ERROR))
                  {
                     ROS_ERROR("ERROR : slave %d is in SAFE_OP + ERROR, attempting ack.", slave);
                     ec_slave[slave].state = (EC_STATE_SAFE_OP + EC_STATE_ACK);
                     ec_writestate(slave);
                  }
                  else if(ec_slave[slave].state == EC_STATE_SAFE_OP)
                  {
                     ROS_WARN("WARNING : slave %d is in SAFE_OP, change to OPERATIONAL.", slave);
                     ec_slave[slave].state = EC_STATE_OPERATIONAL;
                     ec_writestate(slave);                              
                  }
                  else if(ec_slave[slave].state > 0)
                  {
                     if (ec_reconfig_slave(slave, EC_TIMEOUTMON))
                     {
                        ec_slave[slave].islost = FALSE;
                        ROS_INFO("MESSAGE : slave %d reconfigured",slave);                           
                     }
                  } 
                  else if(!ec_slave[slave].islost)
                  {
                     /* re-check state */
                     ec_statecheck(slave, EC_STATE_OPERATIONAL, EC_TIMEOUTRET);
                     if (!ec_slave[slave].state)
                     {
                        ec_slave[slave].islost = TRUE;
                        ROS_ERROR("ERROR : slave %d lost",slave);                           
                     }
                  }
               }
               if (ec_slave[slave].islost)
               {
                  if(!ec_slave[slave].state)
                  {
                     if (ec_recover_slave(slave, EC_TIMEOUTMON))
                     {
                        ec_slave[slave].islost = FALSE;
                        ROS_INFO("MESSAGE : slave %d recovered",slave);                           
                     }
                  }
                  else
                  {
                     ec_slave[slave].islost = FALSE;
                     ROS_INFO("MESSAGE : slave %d found",slave);                           
                  }
               }
            }
            if(!ec_group[currentgroup].docheckstate)
               ROS_INFO("OK : all slaves resumed OPERATIONAL.");
        }
        osal_usleep(10000);
    }   

} 

bool init_EtherCAT( char *devName )
{
	bool result = false;
	int i, chk;
	
	/* create thread to handle slave error handling in OP */
	osal_thread_create((void*)&thread1, 128000, (void*)&ecatcheck, (void*) ctime);	
	
	/* initialise SOEM, bind socket to ifname */
	if (ec_init(devName))
	{   
		ROS_INFO("ec_init on %s succeeded.",devName);
		
		/* find and auto-config slaves */
		if ( ec_config_init(FALSE) > 0 )
		{
			ROS_INFO("%d slaves found and configured.",ec_slavecount);

			ec_config_map(&IOmap);

			ec_configdc();

			ROS_INFO("Slaves mapped, state to SAFE_OP.");
			/* wait for all slaves to reach SAFE_OP state */
			ec_statecheck(0, EC_STATE_SAFE_OP,  EC_TIMEOUTSTATE * 4);


			ROS_INFO("Request operational state for all slaves");
			expectedWKC = (ec_group[0].outputsWKC * 2) + ec_group[0].inputsWKC;
			ROS_INFO("Calculated workcounter %d", expectedWKC);
			ec_slave[0].state = EC_STATE_OPERATIONAL;

			/* send one valid process data to make outputs in slaves happy*/  		 
			ec_send_processdata();
			ec_receive_processdata(EC_TIMEOUTRET);

			/* request OP state for all slaves */
			ec_writestate(0);
			chk = 40;
			/* wait for all slaves to reach OP state */
			do
			{
				ec_send_processdata();
				ec_receive_processdata(EC_TIMEOUTRET);
				ec_statecheck(0, EC_STATE_OPERATIONAL, 50000);
			}
			while (chk-- && (ec_slave[0].state != EC_STATE_OPERATIONAL));
		 
		 
			if (ec_slave[0].state == EC_STATE_OPERATIONAL )
			{
				ROS_INFO("Operational state reached for all slaves.");
				result = true;
				return result;
			}
			else
			{
				ROS_WARN("Not all slaves reached operational state.");
				ec_readstate();
				for(i = 1; i<=ec_slavecount ; i++)
				{
					if(ec_slave[i].state != EC_STATE_OPERATIONAL)
					{
						ROS_INFO("Slave %d State=0x%2.2x StatusCode=0x%4.4x : %s",
							i, ec_slave[i].state, ec_slave[i].ALstatuscode, ec_ALstatuscode2string(ec_slave[i].ALstatuscode));
					}
				}
			}           

				ROS_WARN("Request init state for all slaves");
				ec_slave[0].state = EC_STATE_INIT;
				/* request INIT state for all slaves */
				ec_writestate(0);
		}
		else
		{
			ROS_WARN("No slaves found!");
		}
			
		ROS_WARN("close socket");
		/* stop SOEM, close socket */
		ec_close();
    }
    else
    {
        ROS_ERROR("No socket connection on %s Excecute as root",devName);
		
		result = false;
    } 
	
	return result;
}

void cvtBufferToInt16( short *value, unsigned char *buff )
{
	unsigned char *temp = (unsigned char *)value;
	temp[0] = buff[0];
	temp[1] = buff[1];
}

void changeRFTEC01_ConfigParam( unsigned char param1, unsigned char param2, unsigned char param3, unsigned char param4 )
{
	uint8 *data_ptr;

   data_ptr = ec_slave[g_slave_id].outputs;
   
   data_ptr[0] = param1; // LSB
   data_ptr[1] = param2;
   data_ptr[2] = param3;
   data_ptr[3] = param4; // MSB
  //ROS_INFO("config param : %02x %02x %02x %02x \n", data_ptr[3], data_ptr[2], data_ptr[1], data_ptr[0] );
}

void updateRFT_Data( void )
{
	int i;

	for( i = 0; i < 8; i++ )
		RFT_DATA_FIELD[i] = ec_slave[g_slave_id].inputs[IDX_D1 + i];
	for( i = 0; i < 8; i++ )
		RFT_DATA_FIELD[i + 8] = ec_slave[g_slave_id].inputs[IDX_D9 + i];
	
	for( i = 0; i < 6; i++ )
	{
		cvtBufferToInt16( RFT_FT_RAW + i, ec_slave[g_slave_id].inputs + IDX_RAW_FT1 + i * 2 );
	}
	
	RFT_OverloadStatus = ec_slave[g_slave_id].inputs[IDX_OVERLOAD];
	RFT_ErrorFlag = ec_slave[g_slave_id].inputs[IDX_ERRLR_FLAG];	
	
	RFT_FT[0] = RFT_FT_RAW[0] / g_force_divider; // fx
	RFT_FT[1] = RFT_FT_RAW[1] / g_force_divider; // fy
	RFT_FT[2] = RFT_FT_RAW[2] / g_force_divider; // fz
	RFT_FT[3] = RFT_FT_RAW[3] / g_torque_divider; // tx
	RFT_FT[4] = RFT_FT_RAW[4] / g_torque_divider; // ty
	RFT_FT[5] = RFT_FT_RAW[5] / g_torque_divider; // tz
}

void update_RFTEC01_R4_OutputProcessData(void)
{
	
	if( configCmdType == CMD_NONE )
	{
		changeRFTEC01_ConfigParam( 0, 0, 0, 0 ); 
		configParam[0] = configParam[1] = configParam[2] = 0;
	}
	else
	{
		changeRFTEC01_ConfigParam( configCmdType, configParam[0], configParam[1], configParam[2] ); 
	}	
}
