
#ifndef __RT_RFT_DEFS_H__
#define __RT_RFT_DEFS_H__

#define CMD_NONE					(0)

// command types
#define CMD_GET_PRODUCT_NAME		(1)
#define CMD_GET_SERIAL_NUMBER		(2)
#define CMD_GET_FIRMWARE_VER		(3)
#define CMD_SET_ID					(4)	// Only CAN version
#define CMD_GET_ID					(5) // Only CAN version
#define CMD_SET_COMM_BAUDRATE		(6) // Only UART version, CAN : 1Mbps Fixed
#define CMD_GET_COMM_BAUDRATE		(7) 
#define CMD_SET_FT_FILTER			(8)
#define CMD_GET_FT_FILTER			(9)
#define CMD_FT_ONCE					(10) 
#define CMD_FT_CONT					(11) 
#define CMD_FT_CONT_STOP			(12)
#define CMD_RESERVED_1				(13)
#define CMD_RESERVED_2				(14)
#define CMD_SET_CONT_OUT_FRQ 		(15)	
#define CMD_GET_CONT_OUT_FRQ  		(16)	
#define CMD_SET_BIAS				(17) // No response packet.
#define CMD_GET_OVERLOAD_COUNT		(18)

#define RFT_NUM_OF_FORCE			(6)

#define RFT_PRODUCT_NAME_LENGTH		(15) 
#define RFT_SERIAL_NUMBER_LENGTH	(15)
#define RFT_FIRMWARE_VER_LENGTH		(15)


#define RESPONSE_CAN_PACKET_CNT			(2)
#define COMMAND_PACKET_DATA_FIELD_SIZE	(8)
#define RESPONSE_PACKET_DATA_FIELD_SIZE (16)

// OUTPUT FRQ. DEFINITIONS
#define OUTPUT_FRQ_200Hz_DEFAULT	(0)
#define OUTPUT_FRQ_10Hz				(1)
#define OUTPUT_FRQ_20Hz				(2)
#define OUTPUT_FRQ_50Hz				(3)
#define OUTPUT_FRQ_100Hz			(4)
#define OUTPUT_FRQ_200Hz			(5)
#define OUTPUT_FRQ_300Hz			(6)
#define OUTPUT_FRQ_500Hz			(7)
#define OUTPUT_FRQ_1000Hz			(8)

// FILTER SET VALUE DEFINITIONS
#define FILTER_NONE			(0) // NONE
#define FILTER_1ST_ORDER_LP	(1) // 1st order low-pass filter

// Cutoff Frq.
#define CUTOFF_1Hz		(1)
#define CUTOFF_2Hz		(2)
#define CUTOFF_3Hz		(3)
#define CUTOFF_5Hz		(4)
#define CUTOFF_10Hz		(5)
#define CUTOFF_20Hz		(6)
#define CUTOFF_30Hz		(7)
#define CUTOFF_40Hz		(8)
#define CUTOFF_50Hz		(9)
#define CUTOFF_100Hz	(10)
#define CUTOFF_150Hz	(11)
#define CUTOFF_200Hz	(12)
#define CUTOFF_300Hz	(13)
#define CUTOFF_500Hz	(14)

// BAUDRATE DEFINITIONS
#define CAN_BAUDRATE_1MBPS (0) // 1Mbps, CAN FIXED BIT-RATE
// BAUDRATE FOR UART VERSIONS
#define UART_BAUDRATE_115200_DEFAULT (0)
#define UART_BAUDRATE_921600 (1)
#define UART_BAUDRATE_460800 (2)
#define UART_BAUDRATE_230400 (3)
#define UART_BAUDRATE_115200 (4)
#define UART_BAUDRATE_57600  (5)

// ERROR CODE.
#define ERROR_NONE				(0)
#define NOT_SUPPORTED_CMD		(1)
#define SET_VALUE_RANGE_ERR		(2)
#define EEPROM_WRITING_ERR		(3)


//
#define FORCE_DIVIDER (50.0f)		// default value
#define TORQUE_DIVIDER (2000.0f)	// default value

//
#define OVERLOAD_BIT_FX (0x20)
#define OVERLOAD_BIT_FY (0x10)
#define OVERLOAD_BIT_FZ (0x08)
#define OVERLOAD_BIT_TX (0x04)
#define OVERLOAD_BIT_TY (0x02)
#define OVERLOAD_BIT_TZ (0x01)

#endif //__RT_RFT_DEFS_H__
